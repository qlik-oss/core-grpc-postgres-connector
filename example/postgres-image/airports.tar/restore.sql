--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6 (Debian 10.6-1.pgdg90+1)
-- Dumped by pg_dump version 10.6 (Debian 10.6-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP TABLE public.airports;
SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: airports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.airports (
    rowid integer,
    airport character varying(250),
    city character varying(250),
    country character varying(250),
    iatacode character varying(50),
    icaocode character varying(50),
    latitude character varying(50),
    longitude character varying(50),
    altitude character varying(50),
    timezone character varying(50),
    dst character varying(50),
    tz character varying(50)
);


ALTER TABLE public.airports OWNER TO postgres;

--
-- Data for Name: airports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.airports (rowid, airport, city, country, iatacode, icaocode, latitude, longitude, altitude, timezone, dst, tz) FROM stdin;
\.
COPY public.airports (rowid, airport, city, country, iatacode, icaocode, latitude, longitude, altitude, timezone, dst, tz) FROM '$$PATH$$/2844.dat';

--
-- PostgreSQL database dump complete
--

